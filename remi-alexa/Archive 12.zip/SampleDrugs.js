function SampleDrugs (){

}

var drugName = [
	// drugs on firebase
	"hydrocodone",
	"heroin",
	"drug0"
];

exports.drugName = drugName;